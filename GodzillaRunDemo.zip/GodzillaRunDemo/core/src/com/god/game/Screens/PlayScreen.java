package com.god.game.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.god.game.GodzillaRunDemo;
import com.god.game.Handlers.B2DVars;
import com.god.game.Handlers.B2WorldCreator;
import com.god.game.Handlers.WorldContactListener;
import com.god.game.Scenes.Hud;
import com.god.game.Sprites.Godzilla;
import com.god.game.Sprites.Goomba;

import static com.god.game.GodzillaRunDemo.PPM;

public class PlayScreen implements Screen {

    //Reference to our Game , used to set Screens
    private GodzillaRunDemo game;
    private TextureAtlas atlas;

    //basic playscreen variables
    private OrthographicCamera gameCam;
    private Viewport gamePort;
    private Hud hud;

    //Tiled map variables
    private TmxMapLoader mapLoader;
    private TiledMap map;
    private OrthogonalTiledMapRenderer renderer;

    //Box2d variable
    private World world;
    private Box2DDebugRenderer b2dr;

    //sprites
    private Godzilla player;
    private Goomba goomba;

    private Music music;



    public static int jumpCount = 0;
    public static final int MAX_JUMP_COUNT = 2;

    public PlayScreen(GodzillaRunDemo game) {

        atlas = new TextureAtlas("images/Mario_and_Enermies.pack");

        this.game = game;

        //create cam used to follow godzilla throught cam world
        gameCam = new OrthographicCamera();

        //create a FitViewport to maintain virtual aspect ratio despite
        gamePort = new FitViewport(GodzillaRunDemo.V_WIDTH / PPM, GodzillaRunDemo.V_HEIGHT / PPM, gameCam);

        //create our game HUD for Scores/timers info
        hud = new Hud(game.batch);

        //Load our map and set up our map renderer
        mapLoader = new TmxMapLoader();
        map = mapLoader.load("maps/MAP5.tmx");
        renderer = new OrthogonalTiledMapRenderer(map, 1 / PPM);

        //initially set our gamecam to be centered correctly at the start of...
        gameCam.position.set(gamePort.getWorldWidth() / 2, gamePort.getWorldHeight()/2, 0);

        world = new World(new Vector2(0, -12), true);
        b2dr = new Box2DDebugRenderer();

        new B2WorldCreator(this);

        //create Godzilla in our Game  world
        player = new Godzilla(this);


        WorldContactListener cl = new WorldContactListener();
        world.setContactListener(cl);

        music = GodzillaRunDemo.manager.get("music/bbsong.ogg", Music.class);
        music.setLooping(true);
        music.play();
        music.setVolume(0.5f);
        goomba = new Goomba(this, 2000/PPM,72/PPM);
    }

    public TextureAtlas getAtlas(){
        return atlas;
    }

    @Override
    public void show() {

    }

    private void handleInput(float dt) {

        if(jumpCount < MAX_JUMP_COUNT && Gdx.input.isKeyJustPressed(Input.Keys.SPACE)){
            player.b2body.setLinearVelocity(player.b2body.getLinearVelocity().x,600/PPM);
            jumpCount+=1;
            GodzillaRunDemo.manager.get("sfx/jump.wav", Sound.class).play(0.5f);
        }
    }

    public void update(float dt){
        //handle user input first
        handleInput(dt);

        player.b2body.setLinearVelocity(B2DVars.xSpeed,player.b2body.getLinearVelocity().y);
        gameCam.position.x = player.b2body.getPosition().x; //move gameCam follow player

        //take 1 step in the physics simulation (60 times per second)
        world.step(1/60f, 6, 2);

        player.update(dt);
        goomba.update(dt);
        hud.update(dt);

        //update our gamecam with correct coordinates after change
        gameCam.update();

        //tell our renderer to draw only what our camera can see in our game world.
        renderer.setView(gameCam);
    }



    @Override
    public void render(float delta) {
        //separate our update logic from render
        update(delta);

        //clear the game screen with Black
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT); //wipes the screen clean,then redraws everything fresh

        //render our game map
        renderer.render();

        //renderer our Box2DDebugLines
        b2dr.render(world, gameCam.combined);

        game.batch.setProjectionMatrix(gameCam.combined);
        game.batch.begin();
        player.draw(game.batch);

        goomba.draw(game.batch);

        game.batch.end();


        //set our batch to now draw what the HUD camera sees.
        game.batch.setProjectionMatrix(hud.stage.getCamera().combined);
        hud.stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        gamePort.update(width, height);
    }

    public TiledMap getMap(){
        return map;
    }

    public World getWorld(){
        return world;
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        map.dispose();
        renderer.dispose();
        world.dispose();
        b2dr.dispose();
        hud.dispose();
    }
}
