package com.god.game.Sprites;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.Array;
import com.god.game.GodzillaRunDemo;
import com.god.game.Handlers.B2DVars;
import com.god.game.Screens.PlayScreen;

import static com.god.game.GodzillaRunDemo.PPM;

public class Godzilla extends Sprite {

    public enum State {FALLING, JUMPING, RUNNING}
    public State currentState;
    public State previousState;


    public World world;
    public Body b2body;

    private TextureRegion marioStand;
    private Animation marioRun;
    private Animation marioJump;

    private float stateTimer;
    private boolean runningRight;

    public final float xSpeed = 220 / PPM;


    public Godzilla(PlayScreen screen){
        super(screen.getAtlas().findRegion("big_mario"));

        //initialize default values
        this.world = screen.getWorld();

        defineGodzilla();

        currentState = State.RUNNING;
        previousState = State.RUNNING;
        stateTimer = 0;
        runningRight = true;

        Array<TextureRegion> frames = new Array<TextureRegion>();

        for(int i = 1; i < 4; i++)
            frames.add(new TextureRegion(getTexture(), i * 16, 10, 16, 16));
        marioRun = new Animation(0.1f, frames);
        frames.clear();

        for(int i = 4; i < 6; i++){
            frames.add(new TextureRegion(getTexture(), i * 16, 10, 16, 16));
        }
        marioJump = new Animation(0.1f, frames);


        marioStand = new TextureRegion(getTexture(),0, 10, 16, 16);
        setBounds(0, 0, 32 / PPM, 32 / PPM);
        setRegion(marioStand);

    }

    public void update(float dt){
        setPosition(b2body.getPosition().x - getWidth() / 2, b2body.getPosition().y - getHeight() / 2);
        setRegion(getFrame(dt));
    }

    public TextureRegion getFrame(float dt){
        currentState = getState();

        TextureRegion region;
        switch (currentState){
            case JUMPING:
                region = (TextureRegion) marioJump.getKeyFrame(stateTimer);
                break;
            case RUNNING:
                region = (TextureRegion) marioRun.getKeyFrame(stateTimer, true);
                break;

            case FALLING:
                default:
                    region = (TextureRegion) marioStand;
                    break;
        }

        stateTimer = currentState == previousState ? stateTimer + dt : 0;
        previousState = currentState;
        return region;
    }

    public State getState(){
        if(b2body.getLinearVelocity().y > 0){
            return State.JUMPING;
        }
        else if(b2body.getLinearVelocity().y < 0){
            return State.FALLING;
        }
        else return State.RUNNING;
    }



    public void defineGodzilla(){
        BodyDef bdef = new BodyDef();
        bdef.position.set(GodzillaRunDemo.V_WIDTH / 2 / PPM, 70 / PPM);
        bdef.type = BodyDef.BodyType.DynamicBody;

        //bdef.linearVelocity.set(xSpeed ,0);

        b2body = world.createBody(bdef); //create body in the world

        FixtureDef fdef = new FixtureDef();
        fdef.friction = 0;
        CircleShape shape = new CircleShape();
        shape.setRadius(15 / PPM);

        fdef.filter.categoryBits = B2DVars.GODZILLA_BIT; //which category -> player
        fdef.filter.maskBits = B2DVars.GROUND_BIT
                | B2DVars.COIN_BIT
                | B2DVars.OBSTACLE_BIT // what can player collide with
                | B2DVars.ENEMY_HEAD_BIT;

        fdef.shape = shape;
        fdef.isSensor = false;
        b2body.createFixture(fdef);

        //create body sensor
        CircleShape bodySensor = new CircleShape();
        bodySensor.setRadius(15 / PPM);
        fdef.shape = bodySensor;
        fdef.isSensor =true;
        b2body.createFixture(fdef).setUserData("body");

        //create foot sensor
        PolygonShape foot = new PolygonShape();
        foot.setAsBox(5/PPM ,-5 / PPM, new Vector2(0,-15 /PPM), 0);
        fdef.shape = foot;
        fdef.isSensor = true;
        b2body.createFixture(fdef).setUserData("foot");

    }



}
