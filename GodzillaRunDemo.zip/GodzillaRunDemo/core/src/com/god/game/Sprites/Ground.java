package com.god.game.Sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Rectangle;
import com.god.game.Handlers.B2DVars;
import com.god.game.Screens.PlayScreen;

public class Ground extends InteractiveTiledObject {
    public Ground(PlayScreen screen, Rectangle bounds) {
        super(screen, bounds);
        fixture.setUserData(this);

        setCatagoryFilter(B2DVars.GROUND_BIT);

    }

    @Override
    public void playerHit() {

    }

    @Override
    public void onGround() {
        Gdx.app.log("Ground", "collision");
        PlayScreen.jumpCount = 0;
    }
}
