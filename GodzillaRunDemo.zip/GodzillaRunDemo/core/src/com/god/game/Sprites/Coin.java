package com.god.game.Sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.math.Rectangle;
import com.god.game.GodzillaRunDemo;
import com.god.game.Handlers.B2DVars;
import com.god.game.Scenes.Hud;
import com.god.game.Screens.PlayScreen;

public class Coin extends InteractiveTiledObject {

    private boolean setToDestroy;
    private boolean destroyed;

    public Coin(PlayScreen screen, Rectangle bounds) {
        super(screen, bounds);
        fixture.setUserData(this);

        setCatagoryFilter(B2DVars.COIN_BIT);
    }


    @Override
    public void playerHit() {
        Gdx.app.log("Coin", "collision");
        setCatagoryFilter(B2DVars.DESTROYED_BIT);
        if(getCell() != null) {
            getCell().setTile(null);
            System.out.println("Coin has been Deleted");
        } else {
            System.out.println("NULL");
        }
        Hud.addScore(20);

        GodzillaRunDemo.manager.get("sfx/crystal.wav", Sound.class).play(0.5f);
    }

}
