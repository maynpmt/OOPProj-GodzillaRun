package com.god.game.Sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Rectangle;
import com.god.game.Handlers.B2DVars;
import com.god.game.Screens.PlayScreen;

public class Obstacle extends InteractiveTiledObject {

    public Obstacle(PlayScreen screen, Rectangle bounds) {
        super(screen, bounds);
        fixture.setUserData(this);
        setCatagoryFilter(B2DVars.OBSTACLE_BIT);


    }

    @Override
    public void playerHit() {
        Gdx.app.log("Obstacle", "collision");
        Gdx.app.log("Godzilla", "DIED");

    }
}
