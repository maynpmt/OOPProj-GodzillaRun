package com.god.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.god.game.Screens.PlayScreen;

public class GodzillaRunDemo extends Game {
	//Virtual Screen size and Box2D Scale(Pixels per Meter)
	public static final int V_WIDTH = 800;
	public static final int V_HEIGHT = 480;
	public static final float PPM = 100; //pixels per meter
	public static final String TITLE = "Godzilla Run";



	//private GameStateManager gsm;
	public SpriteBatch batch;
	public static AssetManager manager;
	/*
	private OrthographicCamera cam;
	private OrthographicCamera hudCam;
	public static Content res;

	 */

	@Override
	public void create () {
		batch = new SpriteBatch();

		/*
		res = new Content();
		res.loadTexture("images/bunny.png", "bunny");
		 */

		manager = new AssetManager();
		manager.load("music/bbsong.ogg", Music.class);
		manager.load("sfx/crystal.wav", Sound.class);
		manager.load("sfx/jump.wav", Sound.class);
		manager.load("sfx/hit.wav", Sound.class);
		manager.finishLoading();

		setScreen(new PlayScreen(this));

	}

	@Override
	public void render () {
		Gdx.graphics.setTitle(TITLE + " -- FPS: " + Gdx.graphics.getFramesPerSecond());
		super.render();

	}
	@Override
	public void dispose () {
		batch.dispose();
	}
}
