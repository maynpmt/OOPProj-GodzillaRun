package com.god.game.Handlers;

import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.*;
import com.god.game.Screens.PlayScreen;
import com.god.game.Sprites.Coin;
import com.god.game.Sprites.Ground;
import com.god.game.Sprites.Obstacle;

public class B2WorldCreator {
    public B2WorldCreator(PlayScreen screen) {
        World world = screen.getWorld();
        TiledMap map = screen.getMap();

        // create body and fixture variables
        BodyDef bdef = new BodyDef();
        PolygonShape shape = new PolygonShape(); //for our fixture
        FixtureDef fdef = new FixtureDef();
        Body body;


        // create ground body/fixture
        for( MapObject object : map.getLayers().get("ground").getObjects().getByType(RectangleMapObject.class)){
            Rectangle rect = ((RectangleMapObject) object).getRectangle();

            new Ground(screen, rect);
            fdef.filter.categoryBits = B2DVars.GROUND_BIT;

        }

        // create obstacle bodies/fixtures
        for( MapObject object : map.getLayers().get("obstacle").getObjects().getByType(RectangleMapObject.class)){
            Rectangle rect = ((RectangleMapObject) object).getRectangle();

            new Obstacle(screen, rect);
            fdef.filter.categoryBits = B2DVars.OBSTACLE_BIT;


        }

        // create coin bodies/fixtures
        for( MapObject object : map.getLayers().get("coin").getObjects().getByType(RectangleMapObject.class)){
            Rectangle rect = ((RectangleMapObject) object).getRectangle();

            new Coin(screen, rect);
            fdef.isSensor = true;
            fdef.filter.maskBits = B2DVars.GODZILLA_BIT;

        }

    }
}
