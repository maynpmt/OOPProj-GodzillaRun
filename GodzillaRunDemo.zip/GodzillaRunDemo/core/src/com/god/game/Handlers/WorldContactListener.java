package com.god.game.Handlers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.physics.box2d.*;
import com.god.game.Sprites.Coin;
import com.god.game.Sprites.Enemy;
import com.god.game.Sprites.InteractiveTiledObject;
import com.god.game.Sprites.Obstacle;

public class WorldContactListener implements ContactListener {

    @Override
    public void beginContact(Contact contact) {
        Fixture fixA = contact.getFixtureA();
        Fixture fixB = contact.getFixtureB();

        int cDef = fixA.getFilterData().categoryBits | fixB.getFilterData().categoryBits;

        //body collision
        if(fixA.getUserData() == "body" || fixB.getUserData() == "body"){
            Fixture body = fixA.getUserData() == "body" ? fixA : fixB;
            Fixture object = body == fixA ? fixB : fixA;

        }

        //foot collision
        if(fixA.getUserData() == "foot" || fixB.getUserData() == "foot"){
            Fixture foot = fixA.getUserData() == "foot" ? fixA : fixB; // which one is foot?
            Fixture object = foot == fixA ? fixB : fixA; // another one is object

            if(object.getUserData() != null && InteractiveTiledObject.class.isAssignableFrom(object.getUserData().getClass())){
                ((InteractiveTiledObject) object.getUserData()).onGround();
            }
        }

        switch (cDef){
            case B2DVars.OBSTACLE_BIT | B2DVars.GODZILLA_BIT:
                if(fixA.getFilterData().categoryBits == B2DVars.OBSTACLE_BIT)
                    ((Obstacle) fixA.getUserData()).playerHit();
                else //if(fixB.getFilterData().categoryBits == B2DVars.OBSTACLE_BIT)
                    ((Obstacle) fixB.getUserData()).playerHit();
                break;

            case B2DVars.ENEMY_HEAD_BIT | B2DVars.GODZILLA_BIT:
                if(fixA.getFilterData().categoryBits == B2DVars.ENEMY_HEAD_BIT)
                    ((Enemy) fixA.getUserData()).hitOnHead();
                else //if(fixB.getFilterData().categoryBits == B2DVars.ENEMY_HEAD_BIT)
                    ((Enemy) fixB.getUserData()).hitOnHead();
                break;

            case B2DVars.COIN_BIT | B2DVars.GODZILLA_BIT:
                if(fixA.getFilterData().categoryBits == B2DVars.COIN_BIT)
                    ((Coin) fixA.getUserData()).playerHit();
                else //if(fixB.getFilterData().categoryBits == B2DVars.ENEMY_HEAD_BIT)
                    ((Coin) fixB.getUserData()).playerHit();
                break;

        }



    }

    @Override
    public void endContact(Contact contact) {
        Gdx.app.log("End Contact"," ");

    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold)     {

    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {

    }
}
