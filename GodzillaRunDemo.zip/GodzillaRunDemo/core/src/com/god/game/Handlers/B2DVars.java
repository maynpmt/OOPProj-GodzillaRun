package com.god.game.Handlers;

public class B2DVars {
    //pixels per meter ratio
    public static final float PPM = 100;

    //x speed
    public static final float xSpeed = 220 / PPM;

    //Box2D Collission Bits
    public static final short GROUND_BIT = 1;
    public static final short GODZILLA_BIT = 2;
    public static final short DESTROYED_BIT= 4;
    public static final short COIN_BIT = 8;
    public static final short OBSTACLE_BIT = 16;
    public static final short OBJECT_BIT = 32;
    public static final short ENEMY_BIT = 64;
    public static final short ENEMY_HEAD_BIT = 128;

}
