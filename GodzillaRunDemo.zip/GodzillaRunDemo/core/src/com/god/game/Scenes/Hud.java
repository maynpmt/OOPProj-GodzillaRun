package com.god.game.Scenes;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.god.game.GodzillaRunDemo;



public class Hud implements Disposable {
    public Stage stage;
    /** new camera and new viewport specifically for HUD
     *  so it stays locked there and only renders that part of the screen
     *  and then the world can move around independently on its own
     */
    private Viewport viewPort;

    private Integer worldTimer;
    private float timeCount;
    private static Integer score;


    //scene 2d widgets
    private Label countdownLabel;
    private static Label scoreLabel;
    private Label timeLabel;
    private Label godzillaLabel;

    /*constructor*/
    public Hud(SpriteBatch sb){
        worldTimer = 300;
        timeCount = 0;
        score = 0;

        viewPort = new FitViewport(GodzillaRunDemo.V_WIDTH, GodzillaRunDemo.V_HEIGHT, new OrthographicCamera());
        stage = new Stage(viewPort, sb);

        Table table = new Table();
        table.top();
        table.setFillParent(true);

        countdownLabel = new Label(String.format("%03d", worldTimer), new Label.LabelStyle(new BitmapFont(), Color.WHITE)); //string representation of integer, how many num in countdown timer there'll be, d for integer,and then this going to be worldTimer
        scoreLabel = new Label(String.format("%06d", score), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        timeLabel = new Label("HEART POWER", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        godzillaLabel = new Label("Godzilla", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        //then add them to the table

        table.add(godzillaLabel).expandX().padTop(10);
        table.add(timeLabel).expandX().padTop(10);
        table.row(); //create new row
        table.add(scoreLabel).expandX();
        table.add(countdownLabel).expandX();
        //then, add table to our stage

        stage.addActor(table);


    }

    public void update(float dt){
        timeCount += dt;
        if(timeCount >= 1 ) {
            worldTimer--;
            countdownLabel.setText(String.format("%03d", worldTimer));
            timeCount = 0;
        }
    }

    public static void addScore(int value){
        score+=value;
        scoreLabel.setText(String.format("%06d", score));
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
