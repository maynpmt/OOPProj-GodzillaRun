<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="bg" tilewidth="16" tileheight="16" tilecount="1500" columns="50">
 <image source="bg.jpg" width="800" height="480"/>
</tileset>
