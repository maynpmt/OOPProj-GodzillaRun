package com.god.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.god.game.GodzillaRunDemo;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.width = GodzillaRunDemo.V_WIDTH;
		config.height = GodzillaRunDemo.V_HEIGHT;
		config.title = GodzillaRunDemo.TITLE;
		new LwjglApplication(new GodzillaRunDemo(), config);
	}
}
